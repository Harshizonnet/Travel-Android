package com.example.travels_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class profilDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_detail);
    }
}