package com.example.travels_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Hotelgoa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_hotelgoa);
    }
}