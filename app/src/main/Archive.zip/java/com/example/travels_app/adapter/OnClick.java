package com.example.travels_app.adapter;

public interface OnClick {
    public void ItemOnClick(String nodeId);
}
